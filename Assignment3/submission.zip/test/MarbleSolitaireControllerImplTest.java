import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelImpl;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import java.io.Reader;

import java.io.StringReader;

public class MarbleSolitaireControllerImplTest {


  @Test (expected = IllegalArgumentException.class)
  public void testNullArgToCntrlConstructor() {
    new MarbleSolitaireControllerImpl(null, null);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testNullModelPassed() {
    Reader in = new StringReader("3 4 3 q");
    StringBuilder out = new StringBuilder();
    MarbleSolitaireController initControl = new MarbleSolitaireControllerImpl(in, out);
    initControl.playGame(null);
  }



  @Test
  public void testEndGameBeforeMove() {
    Reader in = new StringReader("3 4 3 q");
    StringBuilder out = new StringBuilder();
    MarbleSolitaireController initControl = new MarbleSolitaireControllerImpl(
            in, out);

    MarbleSolitaireModel initModel = new MarbleSolitaireModelImpl();

    initControl.playGame(initModel);
    assertEquals("Game quit!\nState of game when quit:\n"
+"    O O O\n"
+"    O O O\n"
+"O O O O O O O\n"
+"O O O _ O O O\n"
+"O O O O O O O\n"
+"    O O O\n"
+"    O O O\n"
+"Score: 32\n", out.toString());

  }

  /*@Test
  public void testInputs() throws IOException {
    Reader in = new StringReader("3 4 3 6");
    StringBuilder dontCareOutput = new StringBuilder();
    MarbleSolitaireController c = new MarbleSolitaireControllerImpl(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    MarbleSolitaireModel calc = new ConfirmInputsCalculator(log);

    controller5.go(calc);
    assertEquals("num1 = 3, num2 = 4\n", log.toString());
  }*/

}
