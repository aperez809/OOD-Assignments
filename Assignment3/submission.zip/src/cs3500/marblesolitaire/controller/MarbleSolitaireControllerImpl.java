package cs3500.marblesolitaire.controller;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Scanner;

public class MarbleSolitaireControllerImpl implements MarbleSolitaireController {
  final Readable rd;
  final Appendable ap;
  boolean hasQuit;


  public MarbleSolitaireControllerImpl(Readable rd, Appendable ap) throws IllegalArgumentException {
    if (rd == null || ap == null) {
      throw new IllegalArgumentException("Readable and Appendable must not be null.");
    }

    this.rd = rd;
    this.ap = ap;
  }

  @Override
  public void playGame(MarbleSolitaireModel model) {
    //ensure model is non-null and instantiate Scanner
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null.");
    }


    Scanner sc = new Scanner(this.rd);


    //if the game is over, proceed to end game sequence
    while (!model.isGameOver()) {

      //write both current game state and current score to this.ap
      this.transmitStateAndScore(model);
      this.getMoveCoords(sc, model);
      if (this.hasQuit) {
        this.endGamePlayerQuit(model);
        return;
      }
    }

    this.endGameNoMovesLeft(model);
  }

  //use model param to get game state and score then transmit to this.ap
  private void transmitStateAndScore(MarbleSolitaireModel model) {
    try {
      this.ap.append(String.format("%s\n", model.getGameState()));
      this.ap.append(String.format("Score: %s\n", Integer.toString(model.getScore())));
    }
    catch (IOException e) {
      throw new IllegalStateException("Unable to successfully write to output.");
    }
  }

  //for each of the 4 coordinates in the move, check for either validity or quit
  private void getMoveCoords(Scanner sc, MarbleSolitaireModel model) {
    //Integer fromRow, fromCol, toRow, toCol;
    ArrayList<Integer> coords = new ArrayList<>();
    for (int i = 0; i < 4; i++) {
      Integer val = this.getValidCoordInput(sc, model);
      if (val == null) {
        this.hasQuit = true;
        //coords.add(val);
        return;
        //break;
      }
      coords.add(val - 1);

    }

    /*if (coords.contains(null)) {
      return;
    }*/
/*
    fromRow = this.getValidCoordInput(sc, model);
    fromCol = this.getValidCoordInput(sc, model);
    toRow = this.getValidCoordInput(sc, model);
    toCol = this.getValidCoordInput(sc, model);


    if (fromRow == null || fromCol == null || toRow == null || toCol == null) {
      this.hasQuit = true;
      return;
    }
*/
    try {
      model.move(coords.get(0), coords.get(1), coords.get(2), coords.get(3));
    }
    catch (IllegalArgumentException illArgE) {
      try {
        this.ap.append("Invalid move. Play again. Moves must be made to an"
                              + " unoccupied space from and over a single occupied one in either a "
                              + "vertical or horizontal direction.");
      }
      catch (IOException ioE) {
        throw new IllegalStateException("Unable to successfully write to output.");
      }
    }
  }


  //if user has passed "q" or "Q" to scanner, end game
  private void endGameNoMovesLeft(MarbleSolitaireModel model) {
    try {
      this.ap.append("Game over!\n");
      this.ap.append(String.format("%s\n", model.getGameState()));
      this.ap.append(String.format("Score: %s\n", Integer.toString(model.getScore())));
    }
    catch (IOException e) {
      throw new IllegalStateException("Unable to successfully write to output.");
    }
  }

  private Integer getValidCoordInput(Scanner sc, MarbleSolitaireModel model) {
    //TODO: Add support for quitting input ("Q" or "q")

    while (sc.hasNext()) {

      String val = sc.next();

      try {
        if (Integer.parseInt(val) >= 1) {
          return Integer.parseInt(val);
        }

        else {
          System.out.println("Input must be positive integer greater than 1, Q, or q.");
        }
      }

      catch (NumberFormatException e) {
        if (val.toLowerCase().equals("q")) {
          return null;
        }

        else {
          System.out.println("Input must be positive integer greater than 1, Q, or q.");
        }
      }
    }

    throw new IllegalStateException("Unable to read from input.");
  }


  private void endGamePlayerQuit(MarbleSolitaireModel model) {
    try {
      this.ap.append("Game quit!\n");
      this.ap.append(String.format("State of game when quit:\n%s\n", model.getGameState()));
      this.ap.append(String.format("Score: %s\n", Integer.toString(model.getScore())));
    }
    catch (IOException e) {
      throw new IllegalStateException("Unable to successfully write to output.");
    }
  }
}

